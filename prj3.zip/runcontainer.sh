TORUN=bftasgd
docker rm -f container$1
docker run --rm -it --name container$1 --network mynetwork $TORUN
